﻿using Microsoft.Analytics.Interfaces;
using Microsoft.Analytics.Interfaces.Streaming;
using Microsoft.Analytics.Types.Sql;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ParqueRecreativo.Domain
{
    public class Usuarios
    {
        public int Id { get; set; }

        public string Nombre { get; set; }

        public string Telefono { get; set; }
    }
}