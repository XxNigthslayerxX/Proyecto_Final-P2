﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParqueRecreativo.Domain
{
    internal class Actividades
    {
        public int Id { get; set; }

        public string NombreActividad { get; set; }

        public float costo {  get; set; }

        public 
    }
}
