﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParqueRecreativo.Domain
{
    internal class Reservas
    {
        public int Id {  get; set; }

        public int UsuarioId {get; set;} //Clave Foranea

        public Usuarios Usuarios {get; set;}


    }
}
